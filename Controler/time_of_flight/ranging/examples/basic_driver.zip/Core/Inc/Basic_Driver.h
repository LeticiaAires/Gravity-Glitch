/*
 * Basic_Driver.h
 *
 *  Created on: Apr 5, 2023
 *      Author: jerem
 */

#ifndef INC_BASIC_DRIVER_H_
#define INC_BASIC_DRIVER_H_

#include "stm32f4xx_hal.h"
#include "vl53l5cx_api.h"



//Controller un pin

void Init_Pin_Write(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x, int Default_State);
//Pour initialise le Port PA5 -> Init_Pin(GPIOA, GPIO_Pin_5, 0)
//Cela initialise le Port A5 du périphérique A et port numéro 5 pour l'écriture

void Init_Pin_Read(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x);
//Pour initialise le Port PA5 -> Init_Pin(GPIOA, GPIO_Pin_)
//Cela initialise le Port A5 du périphérique A et port numéro 5 pour la lecture

void Pin_Write(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x, int Default_State);
//Pour écrire sur le Pin PA5 -> Pin_Write(GPIOA, GPIO_Pin_5, 1)

GPIO_PinState Pin_Read(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x);
//Pour lire sur le Pin PA5 -> int value = Pin_Read(GPIOA, GPIO_Pin_5)

void Pin_Toggle(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x);
//Pour Toggle (inverse la valeur actuelle) le Pin PA5 -> Pin_Toggle(GPIOA, GPIO_Pin_5)

void Enable_Port(void);


//Controller un UART

UART_HandleTypeDef Init_USART (USART_TypeDef * USARTx, uint32_t BaudRate);
//Pour initialiser USART3 à la fréquence 115200 -> UART_HandleTypeDef huart = Init_USART(USART3, 115200)
//la fonction return une instance huart donc oublier pas de la sauvegarder

HAL_StatusTypeDef USART_Read(UART_HandleTypeDef * huart, uint8_t * pData, uint16_t Size, uint8_t TimeOut);
//Pour lire sur le USART -> USART_Read(&huart, (uint8_t *) DATA, (uint16_t) strlen(DATA), MaxDelay)
//Oublier pas de CAST vos variables sur le bon format.
//strlen() ne prend en entrée que des STRING de la librairie "String.h"
//Vous pouvez écrire une longueur plus grande que votre DATA. Cependant vous perdez les données dans le Bufffer Receive.

HAL_StatusTypeDef USART_Write(UART_HandleTypeDef * huart, uint8_t * pData, uint16_t Size, uint8_t TimeOut);
//Pour lire sur le USART -> USART_Write(&huart, (uint8_t *) DATA, (uint16_t) strlen(DATA), MaxDelay)
//Oublier pas de CAST vos variables sur le bon format.
//strlen() ne prend en entrée que des STRING de la librairie "String.h"
//Vous pouvez écrire une longueur plus grande que votre DATA (ne pas mettre trop grand, car il enverra du "rien"
//et ça prend du temps)




//Controller VL53L5CX

VL53L5CX_Configuration Init_VL53L5CX(int VL53L5CX_ADDRESS);
//Ne pas oublier d'éteindre les Pin LPn des autres capteurs !

void VL53L5CX_Send_Read_To_UART(VL53L5CX_Configuration Dev, UART_HandleTypeDef * huart);
//Pour lire les valeurs de distances du capteur -> VL53L5CX_Send_Read_To_UART(&huart)
//Les distances sont envoyés sur l'UART directement. sous la forme : DATA1\nDATA2\nDATA3\n....

VL53L5CX_ResultsData VL53L5CX_Read(VL53L5CX_Configuration Dev);

int VL53L5CX_Interprete_Data(VL53L5CX_ResultsData input);




void Error_Handler(void);

#endif /* INC_BASIC_DRIVER_H_ */
