/*
 * Basic_Driver.c
 *
 *  Created on: Apr 5, 2023
 *      Author: Emilie
 */



#include "Basic_Driver.h"
#include "vl53l5cx_api.h"


#include <stdlib.h>
#include <string.h>
#include <stdio.h>



//Controle de PIN

void Init_Pin_Write(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x, int Default_State) {

	Enable_Port();

	HAL_GPIO_WritePin(GPIO_Port_x, GPIO_Pin_x, Default_State);

	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin_x;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIO_Port_x, &GPIO_InitStruct);
}


void Init_Pin_Read(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x) {

	Enable_Port();

	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin_x;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIO_Port_x, &GPIO_InitStruct);
}


void Pin_Write(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x, int State) {
	HAL_GPIO_WritePin(GPIO_Port_x, GPIO_Pin_x, State);
}

GPIO_PinState Pin_Read(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x) {
	return HAL_GPIO_ReadPin(GPIO_Port_x, GPIO_Pin_x);
}

void Pin_Toggle(GPIO_TypeDef * GPIO_Port_x, uint16_t GPIO_Pin_x) {
	return HAL_GPIO_TogglePin(GPIO_Port_x, GPIO_Pin_x);
}



//Controle UART

UART_HandleTypeDef Init_USART (USART_TypeDef * USARTx, uint32_t BaudRate)
{
	UART_HandleTypeDef huart;

	huart.Instance = USARTx;
	huart.Init.BaudRate = BaudRate;
	huart.Init.WordLength = UART_WORDLENGTH_8B;
	huart.Init.StopBits = UART_STOPBITS_1;
	huart.Init.Parity = UART_PARITY_NONE;
	huart.Init.Mode = UART_MODE_TX_RX;
	huart.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart.Init.OverSampling = UART_OVERSAMPLING_16;


	return huart;
}

HAL_StatusTypeDef USART_Write(UART_HandleTypeDef * huart, uint8_t * pData, uint16_t Size, uint8_t TimeOut) {
	return HAL_UART_Transmit(huart, pData, Size, TimeOut);
}

HAL_StatusTypeDef USART_Read(UART_HandleTypeDef * huart, uint8_t * pData, uint16_t Size, uint8_t TimeOut) {
	return HAL_UART_Receive(huart, pData, Size,TimeOut);
}

//Controle Capteur VL53L5CX

__weak uint8_t 				status, loop, isAlive, isReady, i, size;
__weak VL53L5CX_Configuration 	Dev;
__weak VL53L5CX_ResultsData 	Results;

char  				msg[20];


VL53L5CX_Configuration Init_VL53L5CX(int VL53L5CX_ADDRESS) {

	VL53L5CX_Configuration Dev;

	//Ne pas oublier d'éteindre le Pin LPn des autres Modules !

	Dev.platform.address = VL53L5CX_DEFAULT_I2C_ADDRESS;

	vl53l5cx_set_i2c_address(&Dev, VL53L5CX_ADDRESS);

	vl53l5cx_init(&Dev);

	vl53l5cx_is_alive(&Dev, &isAlive);

	vl53l5cx_set_ranging_mode(&Dev, VL53L5CX_RANGING_MODE_CONTINUOUS);

	vl53l5cx_set_ranging_frequency_hz(&Dev, 15);

	vl53l5cx_set_resolution(&Dev,(uint8_t) VL53L5CX_RESOLUTION_8X8);

	vl53l5cx_start_ranging(&Dev);

	vl53l5cx_get_resolution(&Dev, &size);

	return Dev;

}


void VL53L5CX_Send_Read_To_UART(VL53L5CX_Configuration Dev, UART_HandleTypeDef * huart) {
	status = vl53l5cx_check_data_ready(&Dev, &isReady);

	while(!isReady) {
		status = vl53l5cx_check_data_ready(&Dev, &isReady);

		//USART_Write(huart, (uint8_t *) "Not having fun\n", 15, 100);

		HAL_Delay(10);
	}

	if(isReady)
	{
		vl53l5cx_get_ranging_data(&Dev, &Results);

		//printf("Print data no : %3u\n", Dev.streamcount);
		for(i = 0; i < size; i++)
		{
			sprintf(msg, "%4d,", (int) Results.distance_mm[VL53L5CX_NB_TARGET_PER_ZONE * i]);

			USART_Write(huart,(uint8_t *) msg, strlen(msg), 10);
		}
		USART_Write(huart,(uint8_t *) "\n", 2, 10);
	}

	WaitMs(&(Dev.platform), 5);
}

VL53L5CX_ResultsData VL53L5CX_Read(VL53L5CX_Configuration Dev) {
	status = vl53l5cx_check_data_ready(&Dev, &isReady);

	while(!isReady) {
		status = vl53l5cx_check_data_ready(&Dev, &isReady);
		HAL_Delay(10);
	}

	vl53l5cx_get_ranging_data(&Dev, &Results);

	WaitMs(&(Dev.platform), 5);
	return Results;
}

int VL53L5CX_Interprete_Data(VL53L5CX_ResultsData input) {
	int dist = 0;
	for(int i = 0; i < size; i++) {
		dist += input.distance_mm[i];
	}
	dist /= size;
	return dist;
}










void Enable_Port() {
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOE_CLK_ENABLE();
}

