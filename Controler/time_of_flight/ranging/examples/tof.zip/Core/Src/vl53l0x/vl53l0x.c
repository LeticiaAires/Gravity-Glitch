#include "vl53l0x_api.h"
#include "VL53L0X_platform.h"
/*
#include <stdlib.h>
#include <stdio.h>

int DeviceAdresse = 0x52;

int init_VL53L0X() {
	VL53L0X_Dev_t Dev ;
	VL53L0X_SetDeviceAddress(&Dev, VL53L0X_ADRESS);
	VL53L0X_DataInit(Dev);
	VL53L0X_SetDeviceMode (Dev, VL53L0X_DEVICEMODE_CONTINUOUS_RANGING);
	return 1 ;
}

int measure_VL53L0X(){
	VL53L0X_StartMeasurement (VL53L0X_Dev Dev);
	return 1;
}
*/

void init_VL53L0X() {
	VL53L0X_DEV Dev;
	VL53L0X_DataInit(Dev);

	/*
	StaticInit();
	SetReferencesSpadManagement();
	SetRefCalibration();
	SetOffsetCalibration();
	SetXTalkValue();
	SetDeviceMode();
	SetGPIO();
	*/
}
