#include "result.h"
#include <stdio.h>

void print_average(RANGING_SENSOR_Result_t *Result) {
	int8_t j;
	int8_t k;
	int8_t l;
	long res = (long) 0 ;

	int8_t zones_per_line = ((Profile.RangingProfile == RS_PROFILE_8x8_AUTONOMOUS) ||
			(Profile.RangingProfile == RS_PROFILE_8x8_CONTINUOUS)) ? 8 : 4;

	for (j=0; j< Result->NumberOfZones; j+=zones_per_line){
		for (l = 0; l < RANGING_SENSOR_NB_TARGET_PER_ZONE; l++) {
			for (k =(zones_per_line - 1); k >= 0; k--){
				res += (long)Result->ZoneResult[j+k].Distance[l];
			}
		}
	}
	printf("\n Global average : %5ld", res/16);
}
