/*#include "53l5a1_ranging_sensor.h"

static RANGING_SENSOR_ProfileConfig_t Profile;

void print_average(RANGING_SENSOR_Result_t *Result) ;
*/
