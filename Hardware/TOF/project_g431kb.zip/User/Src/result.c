/*#include "result.h"
#include <stdio.h>

// uint8_t txData[] = {76,69,71,79,33,33,33,33,10};
// UART_HandleTypeDef huart1;

void print_average(RANGING_SENSOR_Result_t *Result) {
	int8_t j;
	int8_t k;
	int8_t l;
	long tab[16];
	long res = (long) 0 ;

	int8_t zones_per_line = ((Profile.RangingProfile == RS_PROFILE_8x8_AUTONOMOUS) ||
			(Profile.RangingProfile == RS_PROFILE_8x8_CONTINUOUS)) ? 8 : 4;

	// remplissage du tableau
	for (j=0; j< Result->NumberOfZones; j+=zones_per_line){
		for (l = 0; l < RANGING_SENSOR_NB_TARGET_PER_ZONE; l++) {
			for (k =(zones_per_line - 1); k >= 0; k--){
				res = (long)Result->ZoneResult[j+k].Distance[l];
				tab[j+k] = res;
			}
		}
	}

	// tri du tableau
	for (int i=1; i<15; i++){
		for (int j=0; j<i; j++){
			if (tab[i] < tab[j]) {
				long value = tab[j]; // Greater value
				tab[j] = tab[i];
				tab[i] = value;
			}
		}
	}

	// moyenne de la distance
	res = (tab[6]+tab[7]+tab[8]+tab[9])/4 ;
	printf("\n Distance : %5ld", res);
	// HAL_UART_Transmit(&huart1,txData,sizeof(txData),HAL_MAX_DELAY);
}*/
